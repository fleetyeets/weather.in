__version__ = '1.0.8'

api_key = "f054a8afdf8d658df832afeccd66c806"

